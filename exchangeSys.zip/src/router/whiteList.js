/*
 * @Author: your name
 * @Date: 2020-06-28 09:08:48
 * @LastEditTime: 2020-10-13 11:41:11
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_basicconfiguration-施工云企业信息及配置\src\router\whiteList.js
 */
// 免登录白名单页面
const whiteList = [
    'login'
];
export default whiteList;
