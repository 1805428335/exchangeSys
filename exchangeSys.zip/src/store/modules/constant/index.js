/*
 * @Author: your name
 * @Date: 2020-07-10 09:15:31
 * @LastEditTime: 2020-11-19 12:12:12
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \web_basicconfiguration\src\store\modules\constant\constant.js
 */

const state = {
};
const mutations = {

  };
const actions = {

};
export default {
    namespaced: true,
    state,
    mutations,
    actions
};
