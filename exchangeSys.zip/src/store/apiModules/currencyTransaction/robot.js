/*
 * @Author: your name
 * @Date: 2020-11-19 16:34:27
 * @LastEditTime: 2020-11-19 16:34:27
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \exChange\src\store\apiModules\currencyTransaction\robot.js
 */
