/*
 * @Author: your name
 * @Date: 2020-11-19 12:03:26
 * @LastEditTime: 2020-11-19 13:44:41
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \exChange\src\store\apiModules\index.js
 */

import apiALL from './aggregate';

export default {
  ...apiALL
};
