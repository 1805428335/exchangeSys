<!--
 * @Author: wumaoxia
 * @Date: 2020-11-19 15:50:11
 * @LastEditTime: 2020-11-20 10:05:08
 * @LastEditors: Please set LastEditors
 * @Description: 交易对标
 * @FilePath: \exChange\src\views\currencyTransaction\tradeBenchmarking\tradeBenchmarking.vue
-->
<template>
    <div>交易对标</div>
</template>
