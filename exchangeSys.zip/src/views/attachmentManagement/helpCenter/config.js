/*
 * @Author: your name
 * @Date: 2020-11-20 11:44:05
 * @LastEditTime: 2020-11-20 11:44:05
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \exChange\src\views\attachmentManagement\helpCenter\config.js
 */
