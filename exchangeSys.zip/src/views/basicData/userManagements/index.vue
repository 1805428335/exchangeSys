<template>
<div></div>
</template>

<script>
export default {
name: 'userManagements'
};
</script>

<style scoped>

</style>
