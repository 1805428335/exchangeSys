<template>
<div></div>
</template>

<script>
export default {
name: 'summaryManagement'
};
</script>

<style scoped>

</style>
