<template>

</template>

<script>
export default {
  name: 'registrationStatistics'
};
</script>

<style scoped>

</style>
