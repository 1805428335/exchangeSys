<template>
<div></div>
</template>

<script>
export default {
name: 'orderManagement'
};
</script>

<style scoped>

</style>
